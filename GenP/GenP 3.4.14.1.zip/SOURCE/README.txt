NSudo is a system management tool for advanced users to launch programs with full privileges.

It was created by the M2Team, and it is fully (open source)[https://github.com/M2TeamArchived/NSudo].
Without it, XD and other UWP apps cannot be cured.

However, you can remove it and re-compile the source code of GenP to not require it.

For instructions on how to compile GenP and validate it's safety/authenticity, please check the 'COMPILE.txt' document.
